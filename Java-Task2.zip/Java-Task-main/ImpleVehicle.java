package JavaTask;

public class ImpleVehicle {

	public static void main(String[] args) {
		
		SportsCar SC = new SportsCar("Mazda MX-5.", "Road", "Mazda", 15.4f,"Yes");
		SC.getDetails();
	}

}
