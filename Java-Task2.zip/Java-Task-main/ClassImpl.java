package JavaTask;


public class ClassImpl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Teacher tr = new Teacher("Siva",22,50000);
		tr.getDetails();
		
	}

}
