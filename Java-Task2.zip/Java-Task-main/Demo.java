public class Demo {
    public static void main(String[] args) {
        System.out.println("Vanapalli Tarun Veera Venkat Siva");
    }
}
